//
//  TableViewCell.swift
//  instagram
//
//  Created by kote caava on 5/30/17.
//  Copyright © 2017 konstantine tsaava. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var picture: UIImageView!
    @IBOutlet weak var views: UILabel!
    @IBOutlet weak var uploadDate: UILabel!

}
