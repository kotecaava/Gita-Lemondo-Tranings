//
//  ImageStory.swift
//  instagram
//
//  Created by kote caava on 6/11/17.
//  Copyright © 2017 konstantine tsaava. All rights reserved.
//

import UIKit

class ImageStory: UICollectionViewCell {
    
    
    @IBOutlet weak var collecImage: UIImageView!
    
    
}
