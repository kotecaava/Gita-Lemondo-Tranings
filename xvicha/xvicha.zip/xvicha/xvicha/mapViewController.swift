import UIKit
import GoogleMaps

class mapViewController: UIViewController {

        
        var mapView:GMSMapView?
        override func viewDidLoad() {
            
            super.viewDidLoad()
            
            let camera = GMSCameraPosition.camera(withLatitude: 41.71, longitude: 44.75, zoom: 16.0)

            mapView = GMSMapView.map(withFrame: self.view.bounds, camera: camera)
    
            self.view.insertSubview(mapView!, at: 0)

            
            //so the mapView is of width 200, height 200 and its center is same as center of the self.view
            mapView?.center = self.view.center
            
            self.view.addSubview(mapView!)
            
            
        }
}

    /*
    override func loadView() {
        
        // Create a GMSCameraPosition that tells the map to display the
        // coordinate -33.86,151.20 at zoom level 6.
        let camera = GMSCameraPosition.camera(withLatitude: 41.71, longitude: 44.75, zoom: 16.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        view = mapView
        
        _ = GMSMapView.map(withFrame: .zero, camera: camera)
        mapView.settings.myLocationButton = true
        
 
        
    }
    
    }

*/
